//
//  SceneDelegate.h
//  Orders
//
//  Created by student on 23/05/2020.
//  Copyright © 2020 student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

