//
//  ViewController2.m
//  Orders
//
//  Created by student on 02/06/2020.
//  Copyright © 2020 student. All rights reserved.
//

#import "ViewController2.h"

@interface ViewController2 ()

@end

@implementation ViewController2

@synthesize details_image, details_label, image;
@synthesize details_string;
- (void)viewDidLoad {
    [super viewDidLoad];
    details_label.text = details_string;
    details_image.image = image;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
