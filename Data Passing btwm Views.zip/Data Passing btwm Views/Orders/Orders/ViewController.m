//
//  ViewController.m
//  Orders
//
//  Created by student on 23/05/2020.
//  Copyright © 2020 student. All rights reserved.
//

#import "ViewController.h"
#import "AnimalViewCell.h"
#import "ViewController2.h"


@interface ViewController ()

@end

@implementation ViewController

@synthesize TableView;
NSMutableArray *wild_animals, *wild_names, *domestic_animals, *dom_names, *farm_animals, *farm_names;

- (void)viewDidLoad {
    [super viewDidLoad];
    
wild_animals = [[NSMutableArray alloc] initWithObjects:@"lion.png",@"tiger.png",@"elephant.jpg",@"fox.jpg", nil];
    wild_names = [[NSMutableArray alloc] initWithObjects:@"Lion", @"Tiger", @"Elephant", @"Fox", nil];
    
    domestic_animals = [[NSMutableArray alloc] initWithObjects:@"hamster.jpg",@"fish.jpg",@"dog.jpg",@"cat.jpg", nil];
    dom_names = [[NSMutableArray alloc] initWithObjects:@"Hamster", @"Fish", @"Dog", @"Cat", nil];
    
    farm_animals = [[NSMutableArray alloc] initWithObjects:@"hen.jpg",@"rooster.jpg",@"pig.jpg",@"cow.jpg",@"duck.jpg",  nil];
    farm_names = [[NSMutableArray alloc] initWithObjects:@"Hen", @"Rooster", @"Pig", @"Cow", @"Duck", nil];
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath: indexPath animated:NO];
    
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    if([segue.identifier isEqualToString:@"Myid"]){
        NSIndexPath *index = [self.TableView indexPathForSelectedRow];
        ViewController2 *vc  = segue.destinationViewController;
        if(index.section == 0){
            vc.details_string = [NSString stringWithFormat:@"%@", [wild_names objectAtIndex:index.row]];
            vc.image = [UIImage imageNamed:[wild_animals objectAtIndex:index.row]];
            
        }
        if (index.section == 1) {
            vc.details_string = [NSString stringWithFormat:@"%@", [dom_names objectAtIndex:index.row]];
             vc.image = [UIImage imageNamed:[domestic_animals objectAtIndex:index.row]];            }
        if(index.section == 2){
             vc.details_string = [NSString stringWithFormat:@"%@", [farm_names objectAtIndex:index.row]];
             vc.image = [UIImage imageNamed:[farm_animals objectAtIndex:index.row]];
        }
        
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 70;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return wild_names.count;
    }
    else if (section == 1){
    return dom_names.count;
    }
    else{
        return farm_names.count;
    }
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *items = @"Cell";
    AnimalViewCell *cell = [tableView dequeueReusableCellWithIdentifier:items];
    if (cell == nil ) {
        cell =[[AnimalViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:items];
    }
    
    if (indexPath.section == 0) {
        cell.image_view.image = [UIImage imageNamed:[wild_animals objectAtIndex:indexPath.row]];
        cell.lable_view.text = [wild_names objectAtIndex:indexPath.row];
    }
        if(indexPath.section == 1)
        {
        cell.image_view.image = [UIImage imageNamed:[domestic_animals objectAtIndex:indexPath.row]];
        cell.lable_view.text = [dom_names objectAtIndex:indexPath.row];
            
        }
    if(indexPath.section ==2)
    {
    cell.image_view.image = [UIImage imageNamed:[farm_animals objectAtIndex:indexPath.row]];
    cell.lable_view.text = [farm_names objectAtIndex:indexPath.row];
    }
    
    return cell;
    
    
    
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
 
    if(section ==0){
        return @"Wild Animals";
}
   if(section ==1){
        return @"Domestic Animals";
        }
return @"Farm Animals";
}

-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if(editingStyle == UITableViewCellEditingStyleDelete){
        [wild_names removeObjectAtIndex:indexPath.row];
        [wild_animals removeObjectAtIndex:indexPath.row];
        [dom_names removeObjectAtIndex:indexPath.row];
        [domestic_animals removeObjectAtIndex:indexPath.row];
        [farm_names removeObjectAtIndex:indexPath.row];
        [farm_animals removeObjectAtIndex:indexPath.row];
        [tableView reloadData];
    }
    
}


@end
