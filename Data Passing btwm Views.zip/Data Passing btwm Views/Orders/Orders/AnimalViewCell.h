//
//  AnimalViewCell.h
//  Orders
//
//  Created by student on 01/06/2020.
//  Copyright © 2020 student. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AnimalViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIImageView *image_view;
@property (weak, nonatomic) IBOutlet UILabel *lable_view;



@end

NS_ASSUME_NONNULL_END
