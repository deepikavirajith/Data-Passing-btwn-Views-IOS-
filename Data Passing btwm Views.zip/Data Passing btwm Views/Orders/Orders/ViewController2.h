//
//  ViewController2.h
//  Orders
//
//  Created by student on 02/06/2020.
//  Copyright © 2020 student. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ViewController2 : UIViewController

@property NSString *details_string;
@property UIImage * image;
@property (weak, nonatomic) IBOutlet UIImageView *details_image;
@property (weak, nonatomic) IBOutlet UILabel *details_label;

@end

NS_ASSUME_NONNULL_END
