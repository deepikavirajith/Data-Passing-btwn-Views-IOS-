//
//  AnimalViewCell.m
//  Orders
//
//  Created by student on 01/06/2020.
//  Copyright © 2020 student. All rights reserved.
//

#import "AnimalViewCell.h"

@implementation AnimalViewCell

@synthesize image_view, lable_view;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.image_view.frame = CGRectMake(0, 0, 70, 70);
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
       
    
    // Configure the view for the selected state
}

@end
