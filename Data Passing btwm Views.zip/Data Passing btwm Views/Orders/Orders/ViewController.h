//
//  ViewController.h
//  Orders
//
//  Created by student on 23/05/2020.
//  Copyright © 2020 student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>




@property (weak, nonatomic) IBOutlet UITableView *TableView;



@end

